﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace 前端_后台_登录_管理_结合.Admin
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            //成功，说明文本框、按钮已经具有服务台控件属性，且样式和原本的一样
            //Response.Write(txtLoginName.Text);

            //实现跳转步骤
            //1.获取并判断登录信息是否符合要求，比如用户名和密码都是admin
            //2.如果用户登录信息正确，则跳转到后台管理界面的首页AdminIndex.aspx
            //不符合要求，则提示重新输入登录信息

            string strLoginName = txtLoginName.Text;
            string strLoginPwd = txtLoginPwd.Text;

            if (strLoginName=="admin" && strLoginPwd=="admin")
            {
                //登录验证成功
                //赋Session["Login"]值
                Session["Login"] = "ok";
                //赋 Session["LoginName"]值为当前用户名，可以用于后台管理页面
                Session["LoginName"] = strLoginName;
                //再跳转页面
                Response.Redirect("AdminIndex.aspx");
            }
            else
            {
                Response.Write("<script>alert('用户名或密码错误，请重新登录！');window.location.href='login.aspx';</script>");
            }

        }
    }
}