﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace 前端_后台_登录_管理_结合.Admin
{
    public partial class logout : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //1.清空所有的 Session，也就是清空所有的登录信息
            Session.Abandon();
            //2.跳转，跳转到登录页面
            Response.Redirect("Login.aspx");
            //或者，需要增加退出的提示,则使用：
            //Response.Write("<script>alert('logout...');window.location.href='Login.aspx';</script>");
        }
    }
}