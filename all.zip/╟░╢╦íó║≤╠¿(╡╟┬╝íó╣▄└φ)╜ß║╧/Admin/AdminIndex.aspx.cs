﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace 前端_后台_登录_管理_结合.Admin
{
    public partial class AdminIndex : System.Web.UI.Page
    {

        //定义一个全局的变量，用于存储登录名
        public string strLoginName; 

        protected void Page_Load(object sender, EventArgs e)
        {
            //判断是否已经登录，如果未登录，则提示信息，返回登录页面login.aspx
            //利用Session对象，设置一个Session变量“Login”，并根据它的值来判断是否登录
            //比如值为“ok”时，为已经登录成功，否则未登录
            if (Session["Login"] == null || Session["Login"].ToString() != "ok")
            {
                //如果Session对象值为空或者不为ok，则提示跳转
                //Response.Redirect("login.aspx");

                //加提示信息，并返回
                Response.Write("<script>alert('未登录，请返回！');window.location.href='login.aspx';</script>");
            }
            else
            {
                //如果登录成功，则为账号名变量 strLoginName 赋值
                strLoginName = Session["LoginName"].ToString();
            }
        }
    }
}