﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace 前端_后台_登录_管理_结合
{
    public partial class index : System.Web.UI.Page
    {

        public string strWebTitle = "前后台结合项目";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                strWebTitle += "--首页";
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Admin/AdminIndex.aspx");
        }
    }
}